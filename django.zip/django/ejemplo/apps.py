from django.apps import AppConfig


class EjemploConfig(AppConfig):
    name = 'ejemplo'
